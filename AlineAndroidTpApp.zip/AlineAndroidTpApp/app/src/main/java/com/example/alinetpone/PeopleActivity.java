package com.example.alinetpone;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PeopleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.people_layout);
    }
}
